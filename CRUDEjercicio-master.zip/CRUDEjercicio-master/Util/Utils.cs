﻿using InicioProyectoClasesCRUD.Models;

namespace InicioProyectoClasesCRUD.Util
{
    public class Utils
    {
        public static List<Producto> listaProductos = new List<Producto>()
        {
            new Producto()
            {
                idProducto = 1,
                nombre= "Prodicto 1",
                descripcion= "Descripcion 1",
                cantidad = 1,
            }

        };
    }
}
